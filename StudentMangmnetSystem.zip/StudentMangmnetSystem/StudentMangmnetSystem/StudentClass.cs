﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentMangmnetSystem
{
    public enum StudentClass
    {
        First_Class = 1,
        Second_Class = 2, //there automatic ganrate the index.
        Third_Class = 3,
        Fourth_Class = 4,
        Fifth_Class = 5,    
    }

}
